import 'package:flutter/material.dart';

void main() => runApp(const LOSApp());

class LOSApp extends StatelessWidget {
  const LOSApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'LIGHT OVER STUDIO',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090A10),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C4DFF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LIGHT OVER STUDIO 🎙️'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                colors: [Color(0xFF171326), Color(0xFF0D1B2A)],
              ),
              border: Border.all(color: const Color(0xFF5E35B1)),
            ),
            child: const Column(
              children: [
                Icon(Icons.mic, size: 64, color: Color(0xFF9C7BFF)),
                SizedBox(height: 12),
                Text(
                  'حين يصبح الصوت حياةً للأنمي.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text('LOS • Anime + Cinematic + Dark'),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'الأنميات المدبلجة',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.movie)),
              title: const Text('قريبًا'),
              subtitle: const Text('ستظهر هنا الأنميات التي تقوم بدبلجتها.'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'الحلقات الجديدة',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Card(
            child: ListTile(
              leading: const CircleAvatar(child: Icon(Icons.play_arrow)),
              title: const Text('حلقة جديدة'),
              subtitle: const Text('سيظهر هنا آخر ما يتم نشره.'),
            ),
          ),
        ],
      ),
      bottomNavigationBar: const NavigationBar(
        destinations: [
          NavigationDestination(icon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.search), label: 'بحث'),
          NavigationDestination(icon: Icon(Icons.favorite_border), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
        ],
      ),
    );
  }
}
